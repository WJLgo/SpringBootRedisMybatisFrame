package com.hhu.springbootframe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootframeApplicationTests {

    @Test
    void contextLoads() {
    }

}
